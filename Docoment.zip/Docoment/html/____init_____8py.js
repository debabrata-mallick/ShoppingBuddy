var ____init_____8py =
[
    [ "create_app", "____init_____8py.html#aeb9724624f850cf43f4c1a10b6a248a7", null ]
];