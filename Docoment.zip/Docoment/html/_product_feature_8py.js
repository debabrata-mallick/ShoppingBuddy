var _product_feature_8py =
[
    [ "ProductFeature", "class_product_feature_1_1_product_feature.html", "class_product_feature_1_1_product_feature" ],
    [ "CATEGORY_PATH", "_product_feature_8py.html#af058063a45a8e5871f8e4c87afc59518", null ],
    [ "KEY_MAPPINGS", "_product_feature_8py.html#aafe7edd3bdafae20ba0a828e176aeae9", null ],
    [ "KEYWORD_PATH", "_product_feature_8py.html#a25ea70020c471556a0b47ea543b5289f", null ],
    [ "PRODUCT_PATH", "_product_feature_8py.html#a368ccdcfffd29d0363235f338fe170fd", null ],
    [ "SUBKEY_MAPPINGS", "_product_feature_8py.html#a0078d6819029b353376d39aae576c703", null ],
    [ "WORD_MAPPINGS", "_product_feature_8py.html#a05e54aea3fcbe75d03d9308f45321b95", null ]
];