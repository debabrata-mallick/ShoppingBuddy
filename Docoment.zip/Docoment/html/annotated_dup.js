var annotated_dup =
[
    [ "Amazon", "namespace_amazon.html", "namespace_amazon" ],
    [ "Flipkart", "namespace_flipkart.html", "namespace_flipkart" ],
    [ "ProductFeature", "namespace_product_feature.html", "namespace_product_feature" ],
    [ "ShoppingBuddyAPI", "namespace_shopping_buddy_a_p_i.html", null ]
];