var class_amazon_1_1_amazon_scrapper =
[
    [ "__init__", "class_amazon_1_1_amazon_scrapper.html#a0eac51fab71633a638d07c7efe603b67", null ],
    [ "get_category", "class_amazon_1_1_amazon_scrapper.html#aa99100c2c82fc6f5eb3f316e9d11cdbd", null ],
    [ "get_features", "class_amazon_1_1_amazon_scrapper.html#a0c3c478a6b30f5e894413bf548062828", null ],
    [ "get_info", "class_amazon_1_1_amazon_scrapper.html#a00cb599fde4d40e6e4d3b34741d4e230", null ],
    [ "get_number_of_ratings", "class_amazon_1_1_amazon_scrapper.html#a0924349b036ec75a38802a2a17070d8e", null ],
    [ "get_price", "class_amazon_1_1_amazon_scrapper.html#a68b0dd3756318707ebeecfe3aa2573a7", null ],
    [ "get_ratings", "class_amazon_1_1_amazon_scrapper.html#af54ae63397786c0c55f86514617a9fa1", null ],
    [ "get_title", "class_amazon_1_1_amazon_scrapper.html#a2d9d5e69d3ae67115fb40948844a1a36", null ],
    [ "soup", "class_amazon_1_1_amazon_scrapper.html#aef765553277a40a13956af57ea989020", null ],
    [ "url", "class_amazon_1_1_amazon_scrapper.html#a16a34c4df124604316cce9a7787e892a", null ]
];