var compare_8py =
[
    [ "compareProducts", "compare_8py.html#af4f57dcf9be5bbc4ea8773b0c7008a6b", null ],
    [ "AMAZON_URL", "compare_8py.html#a355e79ef8701599024a959d54dcf3932", null ],
    [ "bp", "compare_8py.html#aab7db4618df537d83221d6212d090ef9", null ],
    [ "FLIPKART_URL", "compare_8py.html#a4e6906a682e52f2d84c0309e52821bf5", null ],
    [ "methods", "compare_8py.html#a5c9ef868e54c18ae83e1624633fc6e83", null ]
];