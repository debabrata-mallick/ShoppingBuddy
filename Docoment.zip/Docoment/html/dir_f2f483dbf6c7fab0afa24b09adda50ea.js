var dir_f2f483dbf6c7fab0afa24b09adda50ea =
[
    [ "Amazon.py", "_amazon_8py.html", [
      [ "AmazonScrapper", "class_amazon_1_1_amazon_scrapper.html", "class_amazon_1_1_amazon_scrapper" ]
    ] ],
    [ "Flipkart.py", "_flipkart_8py.html", "_flipkart_8py" ],
    [ "ProductFeature.py", "_product_feature_8py.html", "_product_feature_8py" ]
];