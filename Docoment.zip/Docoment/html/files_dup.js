var files_dup =
[
    [ "ShoppingBuddyAPI", "dir_72cf060283fdf73825db8b1897ba3403.html", "dir_72cf060283fdf73825db8b1897ba3403" ]
];