var namespace_amazon =
[
    [ "AmazonScrapper", "class_amazon_1_1_amazon_scrapper.html", "class_amazon_1_1_amazon_scrapper" ]
];