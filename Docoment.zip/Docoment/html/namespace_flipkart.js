var namespace_flipkart =
[
    [ "FlipkartScrapper", "class_flipkart_1_1_flipkart_scrapper.html", "class_flipkart_1_1_flipkart_scrapper" ]
];