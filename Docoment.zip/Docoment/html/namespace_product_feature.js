var namespace_product_feature =
[
    [ "ProductFeature", "class_product_feature_1_1_product_feature.html", "class_product_feature_1_1_product_feature" ]
];