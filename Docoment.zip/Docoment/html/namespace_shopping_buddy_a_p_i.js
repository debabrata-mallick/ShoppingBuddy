var namespace_shopping_buddy_a_p_i =
[
    [ "compare", "namespace_shopping_buddy_a_p_i_1_1compare.html", null ]
];