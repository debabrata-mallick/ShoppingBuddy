var namespaces_dup =
[
    [ "Amazon", "namespace_amazon.html", null ],
    [ "Flipkart", "namespace_flipkart.html", null ],
    [ "ProductFeature", "namespace_product_feature.html", null ],
    [ "ShoppingBuddyAPI", "namespace_shopping_buddy_a_p_i.html", "namespace_shopping_buddy_a_p_i" ]
];