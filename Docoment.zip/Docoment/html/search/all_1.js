var searchData=
[
  ['amazon_2',['Amazon',['../namespace_amazon.html',1,'']]],
  ['amazon_2epy_3',['Amazon.py',['../_amazon_8py.html',1,'']]],
  ['amazon_5furl_4',['AMAZON_URL',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a355e79ef8701599024a959d54dcf3932',1,'ShoppingBuddyAPI::compare']]],
  ['amazonscrapper_5',['AmazonScrapper',['../class_amazon_1_1_amazon_scrapper.html',1,'Amazon']]]
];
