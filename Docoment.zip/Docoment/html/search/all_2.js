var searchData=
[
  ['bp_6',['bp',['../namespace_shopping_buddy_a_p_i_1_1compare.html#aab7db4618df537d83221d6212d090ef9',1,'ShoppingBuddyAPI::compare']]]
];
