var searchData=
[
  ['laptop_5finfo_5flist_36',['laptop_info_list',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a46659d165659768973d6db55448993eb',1,'ShoppingBuddyAPI::compare']]]
];
