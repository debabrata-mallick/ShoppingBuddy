var searchData=
[
  ['mapproductfeatures_37',['mapProductFeatures',['../class_product_feature_1_1_product_feature.html#a2101fc17458f9f0871b3550c56222772',1,'ProductFeature::ProductFeature']]],
  ['methods_38',['methods',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a5c9ef868e54c18ae83e1624633fc6e83',1,'ShoppingBuddyAPI::compare']]]
];
