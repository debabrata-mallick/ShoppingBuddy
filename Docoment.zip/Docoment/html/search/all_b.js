var searchData=
[
  ['requirements_2etxt_41',['requirements.txt',['../requirements_8txt.html',1,'']]]
];
