var searchData=
[
  ['url_47',['url',['../class_amazon_1_1_amazon_scrapper.html#a16a34c4df124604316cce9a7787e892a',1,'Amazon.AmazonScrapper.url()'],['../class_flipkart_1_1_flipkart_scrapper.html#a6a458555d573770e0056c6b0f61c0072',1,'Flipkart.FlipkartScrapper.url()']]]
];
