var searchData=
[
  ['word_5fmappings_61',['word_mappings',['../class_product_feature_1_1_product_feature.html#ab63d8b634e7376529c71e36fc823f824',1,'ProductFeature.ProductFeature.word_mappings()'],['../namespace_product_feature.html#a05e54aea3fcbe75d03d9308f45321b95',1,'ProductFeature.WORD_MAPPINGS()']]]
];
