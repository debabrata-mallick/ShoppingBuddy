var searchData=
[
  ['amazonscrapper_49',['AmazonScrapper',['../class_amazon_1_1_amazon_scrapper.html',1,'Amazon']]]
];
