var searchData=
[
  ['flipkartscrapper_50',['FlipkartScrapper',['../class_flipkart_1_1_flipkart_scrapper.html',1,'Flipkart']]]
];
