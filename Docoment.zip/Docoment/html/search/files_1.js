var searchData=
[
  ['amazon_2epy_58',['Amazon.py',['../_amazon_8py.html',1,'']]]
];
