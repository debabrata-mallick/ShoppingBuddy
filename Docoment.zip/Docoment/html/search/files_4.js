var searchData=
[
  ['flipkart_2epy_61',['Flipkart.py',['../_flipkart_8py.html',1,'']]]
];
