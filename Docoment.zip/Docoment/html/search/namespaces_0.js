var searchData=
[
  ['amazon_52',['Amazon',['../namespace_amazon.html',1,'']]]
];
