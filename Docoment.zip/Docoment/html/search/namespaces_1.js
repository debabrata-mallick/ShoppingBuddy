var searchData=
[
  ['flipkart_53',['Flipkart',['../namespace_flipkart.html',1,'']]]
];
