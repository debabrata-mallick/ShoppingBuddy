var searchData=
[
  ['compare_55',['compare',['../namespace_shopping_buddy_a_p_i_1_1compare.html',1,'ShoppingBuddyAPI']]],
  ['shoppingbuddyapi_56',['ShoppingBuddyAPI',['../namespace_shopping_buddy_a_p_i.html',1,'']]]
];
