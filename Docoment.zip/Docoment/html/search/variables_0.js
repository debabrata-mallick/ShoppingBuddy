var searchData=
[
  ['amazon_5furl_88',['AMAZON_URL',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a355e79ef8701599024a959d54dcf3932',1,'ShoppingBuddyAPI::compare']]]
];
