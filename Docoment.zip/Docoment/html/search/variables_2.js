var searchData=
[
  ['flipkart_5furl_90',['FLIPKART_URL',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a4e6906a682e52f2d84c0309e52821bf5',1,'ShoppingBuddyAPI::compare']]]
];
