var searchData=
[
  ['methods_93',['methods',['../namespace_shopping_buddy_a_p_i_1_1compare.html#a5c9ef868e54c18ae83e1624633fc6e83',1,'ShoppingBuddyAPI::compare']]]
];
