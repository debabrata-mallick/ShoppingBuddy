var searchData=
[
  ['soup_94',['soup',['../class_amazon_1_1_amazon_scrapper.html#aef765553277a40a13956af57ea989020',1,'Amazon.AmazonScrapper.soup()'],['../class_flipkart_1_1_flipkart_scrapper.html#a067f0239e1925b9c957ea98ba08d3a9b',1,'Flipkart.FlipkartScrapper.soup()']]],
  ['subkey_5fmap_95',['subkey_map',['../class_product_feature_1_1_product_feature.html#acbfc8d0141bff36fa949fee210854918',1,'ProductFeature::ProductFeature']]],
  ['subkey_5fmappings_96',['SUBKEY_MAPPINGS',['../namespace_product_feature.html#a0078d6819029b353376d39aae576c703',1,'ProductFeature']]]
];
